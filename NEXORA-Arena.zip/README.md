# NEXORA Arena
Frontend demo cho website game online: landing page, game cards, đăng ký/đăng nhập modal và leaderboard responsive.

Lưu ý: đăng ký/đăng nhập hiện chỉ là demo frontend (localStorage), chưa có server/database thật.
Mở `index.html` bằng trình duyệt để xem.
